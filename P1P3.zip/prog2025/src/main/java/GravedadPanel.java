import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GravedadPanel extends JPanel {
    private static final Logger logger = LogManager.getRootLogger();
    private Pelota pelota;
    private Timer timer;

    public GravedadPanel() {
        setPreferredSize(new Dimension(800, 600));
        setBackground(Color.BLACK);
        pelota = new Pelota(30, 30);
    }

    public void iniciarAnimacion(double velocidadX) {
        // Reiniciar la posición y velocidad de la pelota
        logger.info("Simulacion Iniciada");
        logger.info("Empuje Lateral: " + velocidadX);
        pelota.reiniciar();

        pelota.setVelocidadX(velocidadX);
        if (timer != null && timer.isRunning()) {
            timer.stop();
        }

        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pelota.mover();
                repaint();

                //Rebote en el límite 600
                if ((pelota.getY() >= 480 && Math.abs(pelota.getVelocidadY()) < 0.5)) {
                    logger.info("Rebote Finalizado");
                    timer.stop();
                    logger.info("Simulacion Finalizada");
                }
                //Pelota sale del borde 800
                if (pelota.getX() >= 800) {
                    logger.debug("Pelota Salio del Borde");
                }
            }
        });

        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        pelota.dibujar(g);
    }
}
