import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.awt.*;

public class Pelota {
    private static final Logger logger = LogManager.getRootLogger();
    private double x, y;
    private double velocidadX = 0;
    private double velocidadY = 0;
    private final double g = 9.81;
    private final double deltaT = 0.05;
    private final int radio = 30;
    private final double coeficienteRebote = 0.7;

    public Pelota(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void setVelocidadX(double velocidadX) {
        this.velocidadX = velocidadX;
    }

    public void mover() {
        velocidadY += g * deltaT;
        y += velocidadY * deltaT + 0.5 * g * deltaT * deltaT;
        x += velocidadX * deltaT;

        // Rebote en el suelo
        if (y >= 480) {
            y = 480;
            velocidadY = -velocidadY * coeficienteRebote;
            logger.debug("Pelota Reboto");

            //Reducción velocidad
            if (Math.abs(velocidadY) < 1) {
                velocidadY = 0;
            }
        }
    }

    public void reiniciar() {
        x = 30;
        y = 30;
        velocidadX = 0;
        velocidadY = 0;
    }

    public void dibujar(Graphics g) {
        g.setColor(Color.GREEN);
        g.fillOval((int) x, (int) y, radio, radio);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getVelocidadY() {
        return velocidadY;
    }
}
