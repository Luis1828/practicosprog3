import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GravedadFrame extends JFrame {
    private static final Logger logger = LogManager.getRootLogger();
    private GravedadPanel panel;
    private JTextField velocidadField;
    private JButton iniciarBtn;

    public GravedadFrame() {
        setTitle("Simulación de Gravedad");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        panel = new GravedadPanel();
        add(panel, BorderLayout.CENTER);

        // Panel compacto en la esquina superior derecha
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.setPreferredSize(new Dimension(200, 50));

        velocidadField = new JTextField(5);
        iniciarBtn = new JButton("OK");

        iniciarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validar();
            }
        });

        controlPanel.add(new JLabel("Velocidad X:"));
        controlPanel.add(velocidadField);
        controlPanel.add(iniciarBtn);

        //Velocidad Panel
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.add(controlPanel, BorderLayout.EAST);
        containerPanel.setBackground(Color.BLACK);
        add(containerPanel, BorderLayout.NORTH);

        pack();
        setSize(850, 600);
        setResizable(false);
        setVisible(true);
    }

    private void validar() {
        String texto = velocidadField.getText().trim();

        if (!texto.matches("\\d+(\\.\\d+)?")) {
            logger.error("Caracter Invalido");
            JOptionPane.showMessageDialog(this, "Error: Solo se permiten números naturales o decimales.", "Entrada inválida", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double velocidadX = Double.parseDouble(texto);

        if (velocidadX > 5839) {
            logger.error("Velocidad fuera de rango");
            JOptionPane.showMessageDialog(this, "Error: La velocidad máxima permitida es 5839.", "Valor fuera de rango", JOptionPane.ERROR_MESSAGE);
            return;
        }

        panel.iniciarAnimacion(velocidadX);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GravedadFrame());
    }
}
